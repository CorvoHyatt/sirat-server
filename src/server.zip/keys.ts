export default{
    database: {
        host: 'localhost',
        user: 'erikue',
        password: 'erikue2020',
        database: 'sirat_db'
        /*
         host: '192.100.170.207',
        user: 'entornot_database',
        password: 'qGHM6Em AcK7u@',
        database: 'entornot_sirat' 
        */
    }   
}
       